export const stackBase = "flex";
